module kos
